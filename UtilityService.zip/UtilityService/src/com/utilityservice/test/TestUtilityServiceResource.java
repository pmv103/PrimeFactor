package com.utilityservice.test;

import com.utilityservice.UtilityServiceResource;
import javax.ws.rs.core.Response;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 *
 * @author Pradeepkumar M Vishwakarma
 */
public class TestUtilityServiceResource {

    private static final String MSG_SUCCESS = "Prime factor(s) are: ";

    @Test
    public void testGetPrimeFactor() {
        UtilityServiceResource utilityServResource = new UtilityServiceResource();
        Response response = utilityServResource.getPrimeFactors("16");
        System.out.println(response.getEntity());
        assertEquals(MSG_SUCCESS + "2 2 2 2 ", response.getEntity());
    }
}
