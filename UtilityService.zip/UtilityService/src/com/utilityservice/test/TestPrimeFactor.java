package com.utilityservice.test;

import com.utilityservice.PrimeFactor;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 *
 * @author Pradeepkumar M Vishwakarma
 */
public class TestPrimeFactor {

    private static final String MSG_INVALID_INPUT = "Prime factors can not be determined for the given input. Kindly provide any absolute no, which is greater than 1.";
    private static final String MSG_SUCCESS = "Prime factor(s) are: ";
    private static final String MSG_PRIME_NUMBER = "Given number itself is a prime number, hence prime factors can not be determined.";
    private static final String MSG_ERROR = "Exception occurred. ";
    private static final String MSG_INPUTLENGTH_ERROR = "Input length is exceeded. Please provide value up to 9223372036854775807.";

    @Test
    public void testGetPrimeFactor() {

        String numString = "2";

        String result = PrimeFactor.getPrimeFactors(numString);
        
        /**
         * Enter valid positive number which is not itself prime number 
         * e.g 8, 16..etc - (16)
         */        
        //assertEquals(MSG_SUCCESS+"2 2 2 2 ", result);
        
        /**
         * Enter negative number (-8)
         */
        //assertEquals(MSG_INVALID_INPUT, result);
        
        /**
         * Enter any characters (a)
         */
        //assertEquals(MSG_INVALID_INPUT, result);
        
        /**
         * Enter number with decimal(1.2)
         */
        //assertEquals(MSG_INVALID_INPUT, result);
        
        /**
         * If input number length is less than or equal to (2^63 - 1) ~ 9223372036854775807
         * (9223372036854775807)
         */
         //assertEquals(MSG_SUCCESS + "7 7 73 127 337 92737 649657 ", result);
        
        /**
         * If input number length is greater than  to (2^63 - 1) (9223372036854775808)
         */
        //assertEquals(MSG_INPUTLENGTH_ERROR , result);
        
        /**
         * If enter number is 0 or 1(0 or 1)
         */
         //assertEquals(MSG_INVALID_INPUT , result);
        
         /**
          * If enter number is itself a prime number (2)
          */
          assertEquals(MSG_PRIME_NUMBER , result);
           
    }

}
