package com.utilityservice.test;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

/**
 *
 * @author Pradeepkumar M Vishwakarma
 */
public class TestRunner {

    public static void main(String[] args) {

        /**
         * To test Prime factor
         */
        Result result = JUnitCore.runClasses(TestPrimeFactor.class);

        /**
         * To test Rest API service
         */
        // Result result = JUnitCore.runClasses(TestUtilityServiceResource.class);
        //print false if conditioned is failed  
        for (Failure failure : result.getFailures()) {
            System.out.println(failure.toString());
        }
        //print true if conditioned is successfully satisfied 
        System.out.println(result.wasSuccessful());
    }

}
